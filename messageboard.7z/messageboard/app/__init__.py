from flask import Flask, jsonify
from flask_wtf.csrf import CSRFProtect, CSRFError
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os

# Initialize the database instance globally
db = SQLAlchemy()

# Initialize Flask-Limiter outside create_app to make it importable
limiter = Limiter(key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

def create_app():
    """Create and configure an instance of the Flask application."""
    app = Flask(__name__, instance_relative_config=True)

    # Configuration
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'default_secret_key')
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(app.instance_path, 'db.sqlite')
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Initialize extensions with the Flask app
    db.init_app(app)
    limiter.init_app(app)  # Attach limiter to the app here
    Migrate(app, db)
    csrf = CSRFProtect(app)

    # Error handler for CSRF
    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):
        return jsonify(error=str(e.description)), 400

    # Importing and registering the main routes/blueprints
    # Ensure your project structure and imports reflect where your blueprints are defined
    from .views import views as views_blueprint  # Adjusted import based on previous conversations
    app.register_blueprint(views_blueprint)

    @app.errorhandler(404)
    def not_found(error):
        """Return a custom 404 Not Found error page."""
        return "Page not found", 404

    return app
